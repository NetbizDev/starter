<?php
// Template Name: Side Navigation Contact
get_header(); 
echo do_shortcode('[masterslider id="2"]');
 ?>
<div class="container page_new">
        <div class="row">
	<div id="sidebar" style="<?php echo $sidebar_css; ?>">
		<ul class="side-nav">
			<?php wp_reset_query(); ?>
			<?php
			//var_dump($post->ID);
			$post_ancestors = get_ancestors($post->ID, 'page');
			//var_dump($post_ancestors);
			$post_parent = end($post_ancestors);
			//var_dump($post_parent);
			?>
			<?php if(is_page($post_parent)): ?><?php endif; ?>
			<li>
				<?php /* if(is_page($post_parent)): ?>class="current_page_item"<?php endif; ?>><a href="<?php echo get_permalink($post_parent); ?>" title="<?php echo __('Back to Parent Page', 'Avada'); ?>"><?php echo get_the_title($post_parent);*/ ?></a>
			</li>
			<?php
			if($post_parent) {
				$children = wp_list_pages("title_li=&child_of=".$post_parent."&echo=0&exclude=".$post_parent);
			}
 			else {
				$children = wp_list_pages("title_li=&child_of=".$post->ID."&echo=0&exclude=".$post_parent);
			}
			
			if ($children) {
			?>
			<?php echo $children; ?>
			<?php } ?>
		</ul>
		<?php
		$selected_sidebar_replacement = get_post_meta($post->ID, 'sbg_selected_sidebar_replacement', true);
		if(!$selected_sidebar_replacement[0] == 0) {
			//generated_dynamic_sidebar();
		}
		?>
	</div>
	<div id="content" class="side-navigation-contact-content" style="<?php echo $content_css; ?>">
		<?php while(have_posts()): the_post(); ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<span class="entry-title" style="display: none;"><?php the_title(); ?></span>
			<span class="vcard" style="display: none;"><span class="fn"><?php the_author_posts_link(); ?></span></span>
			<?php global $data; if(!$data['featured_images_pages'] && has_post_thumbnail()): ?>
			<div class="image">
				<?php the_post_thumbnail('blog-large-netbiz'); ?>
			</div>
			<?php endif; ?>
			<div class="post-content">
				<?php the_content(); ?>
				<?php wp_link_pages(); ?>
			</div>
			<?php if($data['comments_pages']): ?>
				<?php wp_reset_query(); ?>
				<?php comments_template(); ?>
			<?php endif; ?>
		</div>
		<?php endwhile; ?>
	</div>
<div class="pageSideContact" style="<?php echo $contact_css; ?> ">
    <ul>
        <li>
            <div>
                <span><a href="tel:077-2170170">077-2170170</a></span><img src="<?php echo get_home_url();?>/wp-content/netbiz-images/contact_phone.png"/>
            </div>
        </li>
        <li>
            <div>
                <span>077-2180180</span><img src="<?php echo get_home_url();?>/wp-content/netbiz-images/contact_fax.png"/>
            </div>
        </li>
         <li>
            <div>
                <a href="mailto:mail@netbiz.co.il?Subject=" target="_top"><span>mail@netbiz.co.il</span><img src="<?php echo get_home_url();?>/wp-content/netbiz-images/contact_mail.png"/></a>
            </div>
        </li>
        <li>
            <div style="border-bottom: 0">
                <span><?php _e('קיבוץ גלויות 23, תל אביב','netbiz');?></span><img src="<?php echo get_home_url();?>/wp-content/netbiz-images/contact_home.png"/>
            </div>
        </li>
    </ul>
    <a href="#" id="netbiz-button" data-toggle="modal" data-target="#myModal"><?php _e('צור קשר','netbiz');?></a>
</div>
<div  id="pageBottomSocial">
	<?php
             if(function_exists('display_social4i'))
                 echo display_social4i("small","float-left");
        ?>
</div>
</div>
	</div>
<?php get_footer(); ?>