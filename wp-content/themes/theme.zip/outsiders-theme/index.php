<?php get_header(); ?>

<p>1qqq</p>

<?php get_footer(); ?>