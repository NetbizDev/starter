<?php
	/*
		Template Name: Contact page
		*/
	
	 get_header(); ?>
<div class="container ">
	<div class="row">
		<div class="col-sm-12 image">
				<section id="cd-google-map">
		<div id="google-container">
		</div>
		<div id="cd-zoom-in"></div>
		<div id="cd-zoom-out"></div>
</section>
		</div>	
	</div>	
	<div class="row context">
		<div class="col-md-4">
			<img src="https://www.amberjack.co.il/wp-content/uploads/2017/07/contactform.png"/>
		</div>
		<div class="col-md-8">
			<h2 class="contact_title"><?php the_title(); ?></h2>
			<!-- Alona -->
			<p class="adress">
				<i class="fa fa-map-marker" aria-hidden="true"></i>
				<span><?php the_field('address');?></span>
				<?php if (wp_is_mobile()) { ?><?php } ?>
			</p>
			<p class="contacts">
			<span class="phone"><i class="fa fa-phone" aria-hidden="true"></i> 
				<?php if (wp_is_mobile()) { ?>
				<a href="tel:<?php the_field('phone');?>"><?php the_field('phone');?></a>
				<?php } else { ?>
				<?php the_field('phone'); } ?>
			</span>

				<span class="mail"><i class="fa fa-envelope" aria-hidden="true"></i>
					<a href="mailto:<?php the_field('email');?>"><?php the_field('email');?></a>
				</span>
			</p>
			<p class="time"><?php the_field('time');?></p>
			<p class="waze">
				<span style="text-align:center;">נווט אלינו:‎</span><br/>
				<a class="waze" href="waze://?q=<?php the_field('address');?>" target="_blank"><img src="<?php echo get_template_directory_uri()?>/img/waze.png" style="max-width: 75px;" /></a>
				</p>
			<!-- / Alona -->
		</div>		
	</div>
	<div class="row">
		<p class="text_contact align-center"><?php the_content(); ?></p>
	</div>
	<script type="text/javascript" src="https://www.amberjack.co.il/wp-content/themes/outsiders-theme/g-main.js"></script>

	</div>	

<?php get_footer(); ?>
