<?php get_header(); ?>
<div id="content">
<?php             $background_header = get_field('background_header'); ?>
    <div class="single clearfix" style="background-image:url(<?php echo $background_header['url'] ;?>);">
	    <?php $Hex_color = get_field('color_wrapper_header'); 
$RGB_color = hex2rgb($Hex_color);
$Final_Rgb_color = implode(", ", $RGB_color);
?>
	    <div class="bg_opacity_color" style="background-color:rgba(<?php echo $Final_Rgb_color; ?>, 0.<?php echo the_field('counter_for_opacity'); ?>);">
		    <div class="bodyforheader_port">
    <!--:-|-->
                <?php
            if($previous_post_link):
                               ?>
               <?php else :?>
        <span>&nbsp;</span>
        <h2 class="item_ttl"><?php echo the_title();?></h2>
        <h3 class="item_descr"><span><?php echo the_field('subtitle');?></span></h3>
        <?php if( is_singular('portfolio') ) { ?>
<div class="post-nav">
<div class="alignleft prev-next-post-nav"><?php previous_post_link( '%link', '<i class="fa fa-angle-right" aria-hidden="true"></i>' ) ?></div>
<div class="alignright prev-next-post-nav"><?php next_post_link( '%link', '<i class="fa fa-angle-left" aria-hidden="true"></i>' ) ?></div>
</div><?php } ?>        <?php endif; ?>
                <?php
            
            $logo = get_field('logo');
            
            if ( !empty( $logo ) && $logo['description'] != "" ) :
        ?>
        <a class="portfolio-logo" href="<?php echo $logo['description'];?>" target="_blank"><img  title="<?php echo $logo['title'];?>" class="portfolio-logo" src="<?php echo $logo['sizes']['medium']; ?>" alt="" /></a>
        <?php elseif( !empty( $logo )) : ?>
        <a class="portfolio-logo" title="<?php echo $logo['title'];?>" target="_blank"><img class="portfolio-logo" src="<?php echo $logo['sizes']['medium']; ?>" alt="" title="" /></a>
        <?php  endif;  ?>
       </div>
    </div>
    </div>
    <div class="container">
    <div class="row body_gal">
		<div class="gallery_for_port">
	
<?php 

$images = get_field('slider_for_portfolio');

if( $images ): ?>
    <div id="slider" class="flexslider">
        <ul class="slides">
            <?php foreach( $images as $image ): ?>
                <li>
                    <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" />
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
  <!-- Controls -->

</div>

        
		<div class="information">
			<div class="title_port"><h3><?php echo the_title();?></h3></div>
			<div class="content_port"><?php echo the_content('');?></div>
			<div class="detail_port"><ul id="tech">
			<?php $get_tech = get_terms('tech');
				foreach ($get_tech as $cat) { 
									if(has_term($cat->name,'tech')){	
						 				?>
				<li id="cat-<?php echo $cat->term_id; ?>"><?php echo $cat->name;?></li>
						 		  <?php }
							 		}?>
			</ul>
			<div class="box_for_service">	
			<ul id="service">
			<?php $get_serv = get_terms('service');
				foreach ($get_serv as $cat) { 
				if(has_term($cat->name,'service')){	
						 				?>
						 				
				<li id="cat-<?php echo $cat->term_id; ?>"><?php echo $cat->name;?></li>
						 		  <?php 
							 		  }
							 		}?>
			</ul>	
			</div>
			<div class="goto_project">
			<a href="<?php echo the_field('url_to_project'); ?>" target="_blank"> לאתר<img src="http://netbiz.co.il/wp-content/netbiz-images/homeReadMore_white.png" alt=""></a>
			</div>
			</div>
		</div>
	</div>
    </div>
    <hr class="line_port"/>
	<div class="Link_to">
		        <?php if( is_singular('portfolio') ) { ?>
<div class="post-nav">
	<div class="alignright prev-next-post-nav"><?php next_post_link( '%link', '<i class="fa fa-angle-left" aria-hidden="true"></i>' ) ?></div>
<a href="http://www.netbiz.co.il/portfolio-page/" class="to_cat"><img class="back_to_cat" src="http://www.netbiz.co.il/wp-content/uploads/2016/10/back-to-catalog-02.png"/></a>
<div class="alignleft prev-next-post-nav"><?php previous_post_link( '%link', '<i class="fa fa-angle-right" aria-hidden="true"></i>' ) ?></div>
</div>
<?php } ?>
	</div>	
</div>

<?php get_footer(); ?>
