<?php
/**
 * The sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<div class="goods__filters">

	<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
		<div id="widget-area" class="widget-area" role="complementary">
<aside id="woocommerce_product_categories-2" class="widget woocommerce widget_product_categories">
	<h2 class="widget-title desktop">קולקציית התכשיטים 2018</h2>
	<h2 class="widget-title mobile_">קולקציית התכשיטים 2018</h2>
	
		<ul class="product-categories">

	<?php 
	    $taxonomyName = "product_cat";
    $prod_categories = get_terms($taxonomyName, array(
            'orderby'=> 'name',
            'order' => 'ASC',
            'hide_empty' => 1
    ));  

    foreach( $prod_categories as $prod_cat ) :
            $terms = get_terms($taxonomyName, array('parent' => $prod_cat->term_id, 'orderby' => 'slug', 'hide_empty' => false));
            $cat_thumb_id = get_woocommerce_term_meta( $prod_cat->term_id, 'thumbnail_id', true );
            $cat_thumb_url = wp_get_attachment_thumb_url( $cat_thumb_id );
            $term_link = get_term_link( $prod_cat, 'product_cat' );
            $title_link=get_term_meta($prod_cat->term_id, 'wh_meta_title', true);
           // print_r($prod_cat);
           $current = get_queried_object()->term_id;
           
if($current === $prod_cat->term_id){
    ?>
    <li><a class="cat-item cat-item-<?php echo $prod_cat->term_id; ?> current-cat" href="<?php echo $term_link; ?>" title="<?php echo $title_link; ?>"><?php echo $prod_cat->name; ?></a></li>

    <?php } else { ?>
    <li><a class="cat-item cat-item-<?php echo $prod_cat->term_id; ?>" href="<?php echo $term_link; ?>" title="<?php echo $title_link; ?>"><?php echo $prod_cat->name; ?></a></li>
    
    <?php } ?>
    <?php endforeach; wp_reset_query(); ?>
    </ul>
	<!--<ul class="product-categories">
		<li class="cat-item cat-item-17 current-cat"><a href="https://www.amberjack.co.il/product-category/%d7%98%d7%91%d7%a2%d7%95%d7%aa-%d7%99%d7%94%d7%9c%d7%95%d7%9e%d7%99%d7%9d/">טבעות יהלומים</a></li>
		<li class="cat-item cat-item-20"><a href="https://www.amberjack.co.il/product-category/%d7%aa%d7%9c%d7%99%d7%95%d7%a0%d7%99%d7%9d/">תליונים</a></li>
		<li class="cat-item cat-item-21"><a href="https://www.amberjack.co.il/product-category/%d7%a2%d7%92%d7%99%d7%9c%d7%99%d7%9d/">עגילים</a></li>
		<li class="cat-item cat-item-22"><a href="https://www.amberjack.co.il/product-category/%d7%a6%d7%9e%d7%99%d7%93%d7%99%d7%9d/">צמידים</a></li>
		<li class="cat-item cat-item-81"><a href="https://www.amberjack.co.il/product-category/milk-collection/">לקטלוג MILK COLLECTION יהלומים שחורים</a></li>
		<li class="cat-item cat-item-23"><a href="https://www.amberjack.co.il/product-category/%d7%99%d7%94%d7%9c%d7%95%d7%9e%d7%99%d7%9d/">יהלומים</a></li>
		<li class="cat-item cat-item-19"><a href="https://www.amberjack.co.il/product-category/%d7%98%d7%91%d7%a2%d7%95%d7%aa-%d7%90%d7%91%d7%a0%d7%99-%d7%97%d7%9f/">טבעות אבני חן</a></li></ul>-->
		</aside>		</div><!-- .widget-area -->
	<?php endif; ?>

	<hr/>
	<?php  woocommerce_catalog_ordering();?>

				<?php
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $args = array(
	    'posts_per_page' => 1,
		'orderby' => 'rand',
        'post_type' => 'product',
		'meta_query'     => array(
        	  'relation' => 'OR',
			  				array( // Simple products type
				            'key'           => '_sale_price',
				            'value'         => 0,
				            'compare'       => '>',
				            'type'          => 'numeric'
				        ),
				        array( // Variable products type
				            'key'           => '_min_variation_sale_price',
				            'value'         => 0,
				            'compare'       => '>',
				            'type'          => 'numeric'
				        )
			  )   
     );
    $wp_query = new WP_Query($args);
    if (have_posts()) :
    	while (have_posts()) : the_post(); 
    	
    	$price = get_post_meta($post->ID,'_sale_price', true); ?>
    	
				<div class="onsale_product">
				<h4 class="widget-title">מבצע החודש</h4>
					<a href="<?php echo the_permalink(); ?>">
					<img src="<?php the_post_thumbnail_url('medium');?>">
					<div class="details">
					<?php the_title();?>
					<br/>
					<?php echo  $price . ' &#8362; '; ?>
					</div>
					</a>
				</div>	
    
    	<?php
    	endwhile;
    	endif;
    	wp_reset_query();
    ?>
    <div class="form">
	<?php     	echo do_shortcode('[contact-form-7 id="290" title="Widget"]'); ?>
	</div>			

</div>

