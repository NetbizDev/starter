<div id="gate" ><div class="test"></div>
    <div class="element-scroll">
        <div class="element-scroll-container">
            <div class="content-wrap">
                <div class="logo" alt="Somersby - סומרסבי - סיידר תפוחים אלכוהולי" title="Somersby - סומרסבי - סיידר תפוחים אלכוהולי">
                    <div class="image-box simple responsive auto-load" data-url="<?php echo get_template_directory_uri(); ?>/img/logo-1.png"><div class="loader"></div></div>

                </div>

                <h2><?php echo get_field( 'options_general_gate_text', 'options' ); ?></h2>
                <input class="site_enter_btn" tabindex="0" type="button" value="אישור"  alt="אישור" title="אישור" />

                <div class="locale-select">

                    

                </div>

                <div class="birthday-input">
                    <div class="fields section-year">
                        <div class="field-section year">
                            <div class="section-label">Enter the <span class="highlight">year</span> of your birth</div>
                            <div class="fields-wrapper">
                                <div class="field">
                                    <div class="field-value">1</div>
                                    <div class="field-placeholder">Y</div>
                                    <input type="number">
                                </div>
                                <div class="field">
                                    <div class="field-value">9</div>
                                    <div class="field-placeholder">Y</div>
                                    <input type="number">
                                </div>
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">Y</div>
                                    <input type="number">
                                </div>
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">Y</div>
                                    <input type="number">
                                </div>
                            </div>
                        </div>
                        <div class="field-section month">
                            <div class="section-label">Enter the <span class="highlight">month</span> of your birth</div>
                            <div class="fields-wrapper">
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">M</div>
                                    <input type="number">
                                </div>
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">M</div>
                                    <input type="number">
                                </div>
                            </div>
                        </div>
                        <div class="field-section day">
                            <div class="section-label">Enter the <span class="highlight">day</span> of your birth</div>
                            <div class="fields-wrapper">
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">D</div>
                                    <input type="number">
                                </div>
                                <div class="field is-empty">
                                    <div class="field-value"></div>
                                    <div class="field-placeholder">D</div>
                                    <input type="number">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="gate-feedback">
                        <span data-message-id="error.invalid.over.year">The year you entered appears to be is invalid</span>
                        <span data-message-id="error.invalid.over.month">The month you entered appears to be is invalid</span>
                        <span data-message-id="error.invalid.over.day">The day you entered appears to be is invalid</span>
                        <span data-message-id="error.invalid.under.year">The year you entered appears to be is invalid</span>
                        <span data-message-id="error.invalid.under.month">The month you entered appears to be is invalid</span>
                        <span data-message-id="error.invalid.under.day">The day you entered appears to be is invalid</span>
                        <span data-message-id="error.notLegal">You are not old enough to enter this site</span>
                    </div>
                </div>
                <div class="or-seperator">or</div>
                <div class="facebook-login">
                    <div class="fb-connected">
                        Is this you? <img class='profile-image' src="" alt="">
                        <a href="#" class="continue-button facebook-button button">Yes - Continue</a>
                        <a href="#" class="logout-button button">No - Disconnect</a>
                    </div>
                    <div class="fb-not-connected">
                        <a href="#" class="login-button facebook-button button"><span class="icon icon-fb"></span>Connect with Facebook</a>
                    </div>
                    <div class="gate-feedback">
                        <span data-message-id="error.invalid.notLegal">You are not old enough to enter this site</span>
                        <span data-message-id="success.welcome">Welcome to Pegasus.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>