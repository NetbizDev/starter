<!DOCTYPE html>

<html <?php //language_attributes(); /* TODO: find a way to set locale */ ?> lang="he" dir="ltr">

	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width initial-scale=1.0, maximum-scale=1.0">

		<title><?php wp_title(); ?></title>
<?php if(is_shop()){
	echo '<meta name="robots" content="noindex" />';
	
} ?>
		<meta property="og:title" content="<?php wp_title(); ?>" />
		<meta property="og:site_name" content="Amberjack"/>
		<meta property="og:url" content="<?php echo home_url(); ?>" />
		<meta property="og:description" content="" />
		<meta property="fb:app_id" content="" />
		<meta property="og:image" content="<?php the_post_thumbnail_url(); ?>" />

		<meta name="google-site-verification" content="dk8bwScD6v6x4fS4h35_AFZqQV9gfpj4AZFTDkL-Stc" />


	
		<meta name="twitter:card" content="summary_large_image">
		<?php wp_head(); ?>
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css" />
			<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css" />
						<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.default.css" />

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/vendors/owl.carousel.min.js"></script>
	<!--	<link href="https://fonts.googleapis.com/css?family=Heebo:100,200,300,400,500,600,700,800,900" rel="stylesheet">-->
    <script type='text/javascript'>
        $(document).ready(function() {
            $('.mytooltip').tooltipster({
	            theme: 'tooltipster-light',
	            side : 'bottom'
            });
        });
    </script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header.desktop_");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>

<!-- Google Tag Manager -->

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':

new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],

j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=

'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);

})(window,document,'script','dataLayer','GTM-W9RN7XZ');</script>

<!-- End Google Tag Manager -->


<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1854847314845087'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=1854847314845087&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

<script >
	document.addEventListener( 'wpcf7mailsent', function( event ) {
        dataLayer.push({'event' : 'FormSubmitted'});
    	});

</script>

    </head>
	<body <?php body_class(); ?>>
<!-- Google Tag Manager (noscript) -->

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W9RN7XZ"

height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<!-- End Google Tag Manager (noscript) -->


		<div class="md-modal md-effect-6" id="modal-6">
					<button class="md-close"><i class="fa fa-times" aria-hidden="true"></i></button>
			<div class="md-content">
				<div>
				</div>
			</div>
		</div>
		<div class="md-modal md-effect-6" id="modal-7">
					<button class="md-close"><i class="fa fa-times" aria-hidden="true"></i></button>
			<div class="md-content">
				<div>
        <?php echo do_shortcode('[contact-form-7 id="290" title="Widget"]');?>

				</div>
			</div>
		</div>
			<div class="md-modal md-effect-6" id="modal-8">
			<button class="md-close"><i class="fa fa-times" aria-hidden="true"></i></button>
			<div class="md-content">
				<div>
					<?php echo the_field('video_product'); ?>
				</div>
			</div>
		</div>

<!--<div id="barba-wrapper">
  <div class="barba-container">-->
	  		<?php if(is_page('155')){ ?>
		<script src="https://maps.googleapis.com/maps/api/js?sensor=false&key=AIzaSyBLgSk589-YVVpDT7eckbfy0Tkczj-a7FE" type="text/javascript"></script>
<?php } ?>


		<div id="ip-container" class="ip-container">
		<?php if (is_front_page()) { ?>

		<div id="ip-header" class="ip-header">
				<h1 class="logo">
					<?php $image_alt = get_post_meta( 247, '_wp_attachment_image_alt', true);
						$image_title = get_the_title(247);
						 ?>
					
				<img alt="<?php echo $image_alt; ?>"  title="<?php echo $image_title;?>" src="https://www.amberjack.co.il/wp-content/uploads/2017/07/logo.png"/>

				</h1>
				
				<div class="ip-loader">
					<svg class="ip-inner" width="60px" height="60px" viewBox="0 0 80 80">
						<path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
						<path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
					</svg>
				</div>
				
			</div>
<?php } ?>
<div id="o-wrapper" class="o-wrapper has-push-right">

<header class="mobile_">
	<div class="container">
		<div class="row">
			<div class="col-xs-2">
			<a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="https://www.amberjack.co.il/wp-content/uploads/2017/06/ic_cart.png"/>
<?php global $woocommerce; ?>
<span class="count_w">
 <?php echo $woocommerce->cart->cart_contents_count; ?>
</span>
					</a>
			<div class="dropdown-menu">
			<?php woocommerce_get_template( 'cart/mini-cart.php' );?>
			</div>
		
			</div>
			<div class="col-xs-8">
									<?php $image_alt = get_post_meta( 247, '_wp_attachment_image_alt', true);
																$image_title = get_the_title(247);
 ?>
				<a class="logo_site" href="https://www.amberjack.co.il/"><img alt="<?php echo $image_alt; ?>" title="<?php echo $image_title;?>" src="https://www.amberjack.co.il/wp-content/uploads/2017/07/logo.png"/></a>
			</div>
			<div class="col-xs-2">			
				<div class="c-buttons">
				  	<button id="c-button--push-right" class="c-button"><i class="fa fa-bars" aria-hidden="true"></i></button>
				</div>
			</div>
		</div>
	</div>
</header>
<header class="desktop_">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 header_phone">
		<a class="phone_number" href="tel:036815151"> 6815151 - 03 <i class="fa fa-phone" aria-hidden="true"></i></a>	
			</div>
			<!--<div class="col-sm-6"><?php // echo do_shortcode('[wpdreams_ajaxsearchlite]'); ?></div>-->

		</div>
	</div>
	
	<div class="container menus">
		<div class="row">
		<div class="col-sm-4">
		</div>
		<div class="col-sm-4">
				<?php $image_alt = get_post_meta( 247, '_wp_attachment_image_alt', true);
					$image_title = get_the_title(247);
				?>

				<a class="logo_site" href="https://www.amberjack.co.il/"><img alt="<?php echo $image_alt; ?>" title="<?php echo $image_title;?>"  src="https://www.amberjack.co.il/wp-content/uploads/2017/07/logo.png"/></a>
			</div>
		<div class="col-sm-4">
		</div>

		</div>	
		<div class="row">	
			<div class="col-sm-2">
					<a class="dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="https://www.amberjack.co.il/wp-content/uploads/2017/06/ic_cart.png"/>
<?php global $woocommerce; ?>
<span class="count_w">
 <?php echo  $woocommerce->cart->cart_contents_count;
	  ?>
</span>
					</a>
			<div class="dropdown-menu">
			<?php woocommerce_get_template( 'cart/mini-cart.php' );?>
			</div>
			<?php 	 echo do_shortcode('[wpdreams_ajaxsearchlite]');?>

			</div>		
			<div class="col-sm-10">
							<?php 
								    wp_nav_menu(
        array(
	        'theme_location' => 'second-right-menu',
	        'menu'            => 'second-right-menu',
	        'container'       => 'nav',
	        'container_class' => 'right-top-menu-container',
	        'menu_class'      => 'right-top-menu'
        )
    ); ?>

			</div>
		</div>
	</div>	
</header>
<div class="cont_mobile">