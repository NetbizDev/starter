<?php
	/*
		Template Name: Default page
		*/
	
	 get_header();
	 $header_img=get_field('logo_for_policy');
	 
	  ?>
<div class="container">
		<div class="row header">
			<div class="col-sm-12 image">
			<?php	if( !empty($header_img) ): ?>
				<img src="<?php echo $header_img['url']; ?>" alt="<?php echo $header_img['alt']; ?>" />
			<?php endif; ?>


			</div>	
		</div>	
	<div class="row">
		<div class="col-md-12">
		<p class="text_contact align-center"><?php the_content(); ?></p>
		</div>
	</div>

	</div>	

<?php get_footer(); ?>
