<?php
	/*
		Template Name: About page
		*/
	
	 get_header();
	 $image_1 = get_field('first_image');
	 $image_2 = get_field('second_image');
	 $image_3 = get_field('third_image');

	  ?>
<div class="container ">
	<div class="row logo_about">
		<!--<div class="col-md-12 image">
			<img src="https://www.amberjack.co.il/wp-content/uploads/2017/06/About-logotop.png"/>
		</div>	-->
	</div>	
<section class="row one">
	<div class="col-md-7"><?php if( !empty($image_1) ): ?>

	<img src="<?php echo $image_1['url']; ?>" alt="<?php echo $image_1['alt']; ?>" />

<?php endif; ?>
</div>
	<div class="col-md-5"><div class="text_about"><?php echo the_field('first_text');?></div></div>
</section>
<?php if(wp_is_mobile()){ ?>
<section class="row two">
		<div class="col-md-5"><?php if( !empty($image_2) ): ?>

	<img src="<?php echo $image_2['url']; ?>" alt="<?php echo $image_2['alt']; ?>" />

<?php endif; ?>
</div>

			<div class="col-md-7"><div class="text_about"><?php echo the_field('second_text');?></div></div>

	

</section>

 <?php } else { ?>
<section class="row two">
			<div class="col-md-7"><div class="text_about"><?php echo the_field('second_text');?></div></div>

		<div class="col-md-5"><?php if( !empty($image_2) ): ?>

	<img src="<?php echo $image_2['url']; ?>" alt="<?php echo $image_2['alt']; ?>" />

<?php endif; ?>
</div>


</section>
<?php } ?>
<section class="row three">
		<div class="col-md-7"><?php if( !empty($image_3) ): ?>

	<img src="<?php echo $image_3['url']; ?>" alt="<?php echo $image_3['alt']; ?>" />

<?php endif; ?>
</div>
	<div class="col-md-5"><div class="text_about"><?php echo the_field('third_text');?></div></div>

</section>		
	</div>	


			
<?php get_footer(); ?>
