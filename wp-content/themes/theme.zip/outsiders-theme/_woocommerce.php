<?php

get_header();

echo '1';
?>

<?php
get_footer();?>