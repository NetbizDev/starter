<?php
	/*
		Template Name: Blog Page
		*/
	
	 get_header(); 
	 $image_header=get_field('blog_image');
	 ?>
<div class="container">
	<div class="row">
		<div class="col-md-12 image">
		<?php	if( !empty($image_header) ): ?>
			<img src="<?php echo $image_header['url']; ?>" alt="<?php echo $image_header['alt']; ?>" />
	<?php endif; ?>
		</div>
	</div>	
	<div class="row">
		<div class="col-md-12 text">
			<h1 class="header_title"><?php the_title();?></h1>
			<?php echo the_content(); ?>
		</div>	
	</div>
		<div class="row blog-posts scrollme">
						<?php	 
							$args = array(
											'posts_per_page' => -1
											);
							$loop = new WP_Query($args);
							if($loop->have_posts()) {
							while($loop->have_posts()) : $loop->the_post();     
													?>
			<div class="col-sm-3">
						<div class="mask">
						 <a href="<?php the_permalink();?>"><img width="100%" height="130px" src="<?php echo the_post_thumbnail_url() ;?>"/></a>
                        <h2><a href="<?php the_permalink();?>"><?php echo the_title();?></a></h2>
                        <?php $trimexcerpt = get_the_excerpt();
								$shortexcerpt = mb_strimwidth( $trimexcerpt, 0, 80, '...' ); 
						?>
                        <p class="short_descrip"><span><?php echo $shortexcerpt; ?></span>
                        <a class="has-dropdown button" href="<?php the_permalink();?>" class="info">
קרא עוד</a>                        
                        </p>

						</div>				
				</div>								
							<?php    endwhile;
							} 	wp_reset_query();
							 ?>
		</div>	
</div>	


			
<?php get_footer(); ?>
