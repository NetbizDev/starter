<?php
setcookie('gate', 1, time() + (86400 * 30), '/');
?>