</div><!-- cont_mobile -->
<div class="clearfix">
</div>	
<footer>
<div class="container">
	<div class="row footer">
		<div class="col-md-12 text">
						
			<p> לקביעת פגישה אצלנו בבורסת היהלומים <a class="phone_number" href="tel:036815151"><i class="fa fa-phone" aria-hidden="true"></i> 6815151 - 03</a></p>

		</div>
	</div>
	<div class="row">	
		<div class="col-md-12">
			<a class="sas_link" href="http://sasportas-diamonds.com/">
			<img class="sas_logo" src="https://www.amberjack.co.il/wp-content/uploads/2017/10/Sas-logo.png">
			</a>
		</div>	
	</div>
	<div class="row contacts">
		<div class="col-md-12">
		<p class="desktop_">
			<span><a target="_blank" href="https://www.facebook.com/amberjack.jewelry/"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></span>
<span class="mini-contacts"> <a href="mailto:info@amberjack.co.il"><i class="fa fa-envelope" aria-hidden="true"></i> info@amberjack.co.il  </a> </span>
			<span class="mini-contacts"> <i class="fa fa-phone" aria-hidden="true"></i> 03-6815151 </span>
			<!--<span class="mini-contacts">3</span>-->
			<span class="mini-contacts"> <i class="fa fa-map-marker" aria-hidden="true"></i> הבורסה ליהלומים, בניין יהלום  קומה 8  רח’ תובל 21, רמת גן</span>
		</p>
		<ul class="mobile_">
			<li><a href="https://www.facebook.com/amberjack.jewelry/"><i class="fa fa-facebook-square" aria-hidden="true"></i></a></li>
<li class="mini-contacts"> <a href="mailto:info@amberjack.co.il"> info@amberjack.co.il <i class="fa fa-envelope" aria-hidden="true"></i> </a> </li>
			<li class="mini-contacts"> <i class="fa fa-phone" aria-hidden="true"></i> 03-6815151 </li>
			<!--<span class="mini-contacts">3</span>-->
			<li class="mini-contacts"> <i class="fa fa-map-marker" aria-hidden="true"></i> הבורסה ליהלומים, בניין יהלום  קומה 8  רח’ תובל 21, רמת גן</li>
		</ul>
		
		
		</div>		
	</div>		
	<div class="row">
		<div class="col-md-4">
<p class="copyrights">כל הזכויות שמורות לחברת אמברג'ק 2018</p>
		</div>	
		<div class="col-md-4">
<p class="policy">
	<a target="_blank" href="https://www.amberjack.co.il/%D7%AA%D7%A0%D7%90%D7%99-%D7%A9%D7%99%D7%9E%D7%95%D7%A9-%D7%95%D7%9E%D7%93%D7%99%D7%A0%D7%99%D7%95%D7%AA-%D7%94%D7%97%D7%96%D7%A8%D7%94/">	תנאי שימוש ומדיניות החזרה</a>
</p>
			</div>	
		<div class="col-md-4 inform">
		<p class="developedby">					האתר נבנה ע"י 	
<a href="https://www.netbiz.co.il" target="_blank"><img class="logo_netbiz" src="https://www.amberjack.co.il/wp-content/uploads/2017/08/logo_netbiz.png"/></a>

		</p>

		</div>
	</div>	
	</div>
<!--	<div class="row">
		<div class="col-md-6">
			<a class="policy" href="https://www.amberjack.co.il/%D7%AA%D7%A0%D7%90%D7%99-%D7%A9%D7%99%D7%9E%D7%95%D7%A9-%D7%95%D7%9E%D7%93%D7%99%D7%A0%D7%99%D7%95%D7%AA-%D7%94%D7%97%D7%96%D7%A8%D7%94/">תנאי שימוש ומדיניות החזרה</a>
		</div>
		<div class="col-md-6">
			<span class="createdby"> © כל הזכויות שמורות ל AMBERJACK 2017 האתר נבנה ע"י נטביז שירותי תוכנה</span>
			<a href="https://www.netbiz.co.il" target="_blank"><img class="logo_netbiz" src="https://www.amberjack.co.il/wp-content/uploads/2017/08/logo_netbiz.png"/></a>
		</div>
	</div>-->
</div>	
</footer>
</div>
</div>
<nav id="c-menu--push-right" class="c-menu c-menu--push-right">
   <button class="c-menu__close"><strong>x</strong></button>
 
  <?php 
		wp_nav_menu(
        array(
	        'theme_location' => 'primary',
	        'menu'            => 'primary',
	        'container'       => 'ul',
	        'container_class' => 'c-menu__items',
	       //	'menu_class'      => 'dropdown-menu',
	       	'menu_id'		=> 'c-menu__item'	

        )
    ); ?>

</nav><!-- /c-menu slide-right -->

<?php wp_footer(); ?>
<!--<script type="text/javascript">
	fullpage.initialize('#fullpage', {
		anchors: ['firstPage', 'secondPage', '3rdPage', '4thpage', 'lastPage'],
		menu: '#menu',
		css3:true
	});

</script>-->
<!--		<script>
		(function() {
			var lineMaker = new LineMaker({
					parent: { element: document.getElementById('section0'), position: 'append' },
					position: 'fixed',
					lines: [
						{top: 0, left: '0', width: '20vw', height: '100vh', color: '#F85659', hidden: false, animation: { duration: 1000, easing: 'easeInOutCirc', delay: 0, direction: 'TopBottom' }},
						{top: 0, left: '20vw', width: '20vw', height: '100vh', color: '#fff', hidden: false, animation: { duration: 1000, easing: 'easeInOutCirc', delay: 150, direction: 'BottomTop' }},
						{top: 0, left: '40vw', width: '20vw', height: '100vh', color: '#F85659', hidden: false, animation: { duration: 1000, easing: 'easeInOutCirc', delay: 300, direction: 'TopBottom' }},
						{top: 0, left: '60vw', width: '20vw', height: '100vh', color: '#fff', hidden: false, animation: { duration: 1000, easing: 'easeInOutCirc', delay: 450, direction: 'BottomTop' }},
						{top: 0, left: '80vw', width: '20vw', height: '100vh', color: '#F85659', hidden: false, animation: { duration: 1000, easing: 'easeInOutCirc', delay: 600, direction: 'TopBottom' }}
					]
			});
			
			setTimeout(function() {
				lineMaker.animateLinesOut();
			}, 500);
		})();
		</script>-->

<div id="c-mask" class="c-mask"></div><!-- /c-mask -->
		<div class="container button_mob">
			<div class="row">
      <div class="col-md-4 col-md-offset-4">
        <div class="material-button-anim">
          <ul class="list-inline" id="options">
            <li class="option">
              <button class="material-button option1" type="button" onclick="location.href='tel:03-6815151'">
                <span class="fa fa-phone" aria-hidden="true"></span>
              </button>
            </li>
            <li class="option">
              <button class="material-button option2" type="button" onclick="location.href='mailto:info@amberjack.co.il'">
                <span class="fa fa-envelope-o" aria-hidden="true"></span>
              </button>
            </li>
            <li class="option">
              <button class="material-button option3 md-trigger" type="button"  data-modal="modal-7">
                <span class="fa fa-pencil" aria-hidden="true"></span>
              </button>
            </li>
          </ul>
          <button class="material-button material-button-toggle" type="button">
            <span class="fa fa-envelope-o" aria-hidden="true"></span>
          </button>
        </div>
      </div>
	</div>
	</div>

<div id="feedback" class="feedback">

    
    <div class="section">
        <?php echo do_shortcode('[contact-form-7 id="290" title="Widget"]');?>
        <h6>
        <span class="arrow up"><i class="fa fa-chevron-up" aria-hidden="true"></i></span> 
לקביעת פגישה </h6>
    </div>
</div>

		<div class="md-overlay"></div><!-- the overlay element -->
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/vendors/modalEffects.js"></script>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/vendors/menu.js"></script>
		
<?php if (is_front_page()) { ?>
		<script>
$('.md-trigger').on('click', function () { 
 $('#modal-6 div.md-content div').html('<iframe width="100%" height="315" src="https://www.youtube.com/embed/Cjo3rXhZPv4?enablejsapi=1" frameborder="0" allowfullscreen></iframe>');  
});
$('.md-overlay').on('click', function () {
 $('div.md-content div').html('');
});			
$('.md-close').on('click', function () {
 $('div.md-content div').html('');
});			

		</script>
		

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/vendors/main-prel.js"></script>

<script >
	  var pushRight = new Menu({
    wrapper: '#o-wrapper',
    type: 'push-right',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var pushRightBtn = document.querySelector('#c-button--push-right');
  
  pushRightBtn.addEventListener('click', function(e) {
    e.preventDefault;
    pushRight.open();
  });
  
</script>
<?php } else { ?>
	<script>
$('.md-overlay').on('click', function () {
    $("#modal-8 iframe").attr("src", $("#modal-8 iframe").attr("src"));
});			
$('.md-close').on('click', function () {
    $("#modal-8 iframe").attr("src", $("#modal-8 iframe").attr("src"));
});			

		</script>

 
 <?php } ?>
<script type="text/javascript">
	
$('.owl-carousel').owlCarousel({
    center: true,
    items:1,
    loop:true,
    autoPlay:true,
    autoPlayTimeout:3000,
    autoPlayHoverPause:true,
    autoPlaySpeed:5000

    //margin:10,
    
});
	$(".read__").click(function() {
	$(".descrpition-category").toggleClass("reveal-open");
});

</script>

<?php if(wp_is_mobile()) { ?>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/vendors/menu.js"></script>

<script >
	  var pushRight = new Menu({
    wrapper: '#o-wrapper',
    type: 'push-right',
    menuOpenerClass: '.c-button',
    maskId: '#c-mask'
  });

  var pushRightBtn = document.querySelector('#c-button--push-right');
  
  pushRightBtn.addEventListener('click', function(e) {
    e.preventDefault;
    pushRight.open();
  });
	

  </script>
<?php } ?>
<!--<script src="<?php echo get_template_directory_uri(); ?>/js/instantclick.min.js" data-no-instant></script>-->
<script type="text/javascript">    
	    var attachFastClick = Origami.fastclick;
        attachFastClick(document.body);
</script>

<script type="text/javascript">
	$(document).ready(function(){
	});
	</script>


</body>

</html>
